﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        double prviBroj, rezultat;
        IzabranaOperacija izabranaOperacija;
        public MainWindow()
        {
            InitializeComponent();

            izbrisiDugme.Click += IzbrisiDugme_Click;
            negativDugme.Click += NegativDugme_Click;
            procenatDugme.Click += ProcenatDugme_Click;
            jednakoDugme.Click += JednakoDugme_Click;
        }

        private void JednakoDugme_Click(object sender, RoutedEventArgs e)
        {
            double drugiBroj;
            if (double.TryParse(rezultatLabel.Content.ToString(), out drugiBroj))
            {
                switch (izabranaOperacija)
                {
                    case IzabranaOperacija.Sabiranje:
                        rezultat=Racunanje.Sabiranje(prviBroj, drugiBroj);
                        break;
                    case IzabranaOperacija.Oduzimanje:
                        rezultat=Racunanje.Oduzimanje(prviBroj, drugiBroj);
                        break;
                    case IzabranaOperacija.Mnozenje:
                        rezultat=Racunanje.Mnozenje(prviBroj, drugiBroj);
                        break;
                    case IzabranaOperacija.Deljenje:
                        rezultat=Racunanje.Deljenje(prviBroj, drugiBroj);
                        break;
                }

                rezultatLabel.Content = rezultat.ToString();
            }
        }

        private void ProcenatDugme_Click(object sender, RoutedEventArgs e)
        {
            double tempBroj;
            //pokusava da parsira string rezultat u double prviBroj
            if (double.TryParse(rezultatLabel.Content.ToString(), out tempBroj))
            {
                tempBroj = tempBroj / 100;
                if(prviBroj != 0)
                {
                    tempBroj *= prviBroj;
                    rezultatLabel.Content = tempBroj.ToString();
                }
                
            }
        }

        private void NegativDugme_Click(object sender, RoutedEventArgs e)
        {
            //pokusava da parsira string rezultat u double prviBroj
            if(double.TryParse(rezultatLabel.Content.ToString(), out prviBroj))
            {
                // (-7) x (-1) = 7   (7) X (-1) = -7
                prviBroj = prviBroj * -1;
                rezultatLabel.Content = prviBroj.ToString();
            }
        }

        private void IzbrisiDugme_Click(object sender, RoutedEventArgs e)
        {
            rezultatLabel.Content = "0";
            rezultat = 0;
            prviBroj = 0;
        }

        private void operacijaDugme_Click(object sender, RoutedEventArgs e)
        {
            //parsira ga u string i pozdravlja rezultat 0 (sprema kalkulator za drugi broj)
            if (double.TryParse(rezultatLabel.Content.ToString(), out prviBroj))
            {
                rezultatLabel.Content = "0";
            }

            if (sender == sabiranjeDugme)
                izabranaOperacija = IzabranaOperacija.Sabiranje;
            if (sender == oduzimanjeDugme)
                izabranaOperacija = IzabranaOperacija.Oduzimanje;
            if (sender == mnozenjeDugme)
                izabranaOperacija = IzabranaOperacija.Mnozenje;
            if (sender == deljenjeDugme)
                izabranaOperacija = IzabranaOperacija.Deljenje;
        }

        private void zarezDugme_Click(object sender, RoutedEventArgs e)
        {
            if (rezultatLabel.Content.ToString().Contains("."))
            {
                //nista ne radi
            }
            else
            {
                rezultatLabel.Content = $"{rezultatLabel.Content}.";
            }
            
        }

        private void BrojDugme_Click(object sender, RoutedEventArgs e)
        {
            /*
             *  int izabraniBroj = 0;
             *  
             *  if (sender == nulaDugme) izabraniBroj = 0;
             *  if (sender == jedanDugme) izabraniBroj = 1;
             *  if (sender == dvaDugme) izabraniBroj = 2;
             *  if (sender == triDugme) izabraniBroj = 3;
             *  if (sender == cetiriDugme) izabraniBroj = 4;
             *  if (sender == petDugme) izabraniBroj = 5;
             *  if (sender == sestDugme) izabraniBroj = 6;
             *  if (sender == sedamDugme) izabraniBroj = 7;
             *  if (sender == osamDugme) izabraniBroj = 8;
             *   if (sender == devetDugme) izabraniBroj = 9;
             *   
             */

            int izabraniBroj = int.Parse((sender as Button).Content.ToString());

            //proverava da li je rezultat 0,ako jeste upisu 7 ako nije dodaje na postoji broj 7
            if (rezultatLabel.Content.ToString() == "0")
            {
                rezultatLabel.Content = $"{izabraniBroj}";
            }
            else
            {
                rezultatLabel.Content = $"{rezultatLabel.Content}{izabraniBroj}";
            }
        }
    }

    public enum IzabranaOperacija
    {
        Sabiranje,
        Oduzimanje,
        Mnozenje,
        Deljenje
    }

    public class Racunanje
    {
        public static double Sabiranje(double broj1,double broj2)
        {
            return broj1 + broj2;
        }
        public static double Oduzimanje(double broj1, double broj2)
        {
            return broj1 - broj2;
        }
        public static double Mnozenje(double broj1, double broj2)
        {
            return broj1 * broj2;
        }
        public static double Deljenje(double broj1, double broj2)
        {
            if(broj2 == 0)
            {
                MessageBox.Show("Deljenje sa 0 nije moguce", "Pogresna Operacija", MessageBoxButton.OK, MessageBoxImage.Error);
                return 0;
            }
            return broj1 / broj2;
        }
    }
}
